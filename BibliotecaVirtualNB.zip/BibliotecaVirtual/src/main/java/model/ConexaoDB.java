package model;

public class ConexaoDB {
    
}
